#include "server.h"

Server::Server()
{}

void Server::startServer()
{
    if (this->listen(QHostAddress::Any, 5555)){
        qDebug() << "Server is running";
    } else {
        qDebug() << "ERROR Server is not running";
    }
}

void Server::incomingConnection(qintptr socketDescriptor)
{
    socket = new QTcpSocket(this);
    socket->setSocketDescriptor(socketDescriptor);
    connect(socket, &QTcpSocket::readyRead, this, &Server::slotReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &Server::userDisconnected);
    qDebug() << "new connection";

    Sockets.push_back(socket);
}

void Server::slotReadyRead()
{
    qDebug() << "DATA CAME";
    socket = (QTcpSocket*)sender();
    //QDataStream in(socket);
    Data = socket->readAll();
    QJsonDocument jsonDoc = QJsonDocument::fromJson(Data);
    QJsonObject rootObject = jsonDoc.object();
    metadata = rootObject["metadata"].toObject();
    QString data64 = rootObject["data"].toString();
    QByteArray newData = QByteArray::fromBase64(data64.toUtf8());
    QString data = QString::fromUtf8(newData);
    /*
    in.setVersion(QDataStream::Qt_6_2);
    if (in.status() == QDataStream::Ok) {
        while(true)
        {
            if (BlockSize == 0){
                if (socket->bytesAvailable() < 2){
                    break;
                }
                in >> BlockSize;
            }
            if (socket->bytesAvailable() < BlockSize){
                break;
            }
            in >> data;
        }
    } else {
        qDebug() << "ERROR Data lose";
    }

    metadata = QJsonDocument::fromJson(socket->readAll()).object();
*/
    qDebug() << data << BlockSize << metadata["type"].toString();

    if (metadata["type"].toString() == "register"){
        registerUser(data);
    }
    else if (metadata["type"].toString() == "login"){
        LogInUser(data);
    }
}

void Server::userDisconnected()
{
    socket = (QTcpSocket*)sender();
    if (socket) {
        socket->deleteLater();
    }
    qDebug() << "USER DISCONNECTED";
}

void Server::sendToClient(QString data)
{
    Data.clear();
    QDataStream out(&Data, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_2);
    out << data;
    for (auto socket : Sockets)
    {
        socket->write(Data);
    }
}

void Server::registerUser(QString log_pass)
{
    //регистрация (пока что не пашет (сначала писал это в самом мессенджере (кринж)))
    /*
    QString login = ui->loginInput->text();
    QString password = ui->passwordInput->text();
    if (database.registerUser(login, password) && !login.isEmpty() && !password.isEmpty())
    {
        ui->label_3->setText("seccesfully registered");
    }
    else
    {
        ui->label_3->setText("this user already exists");
    }
*/
    qDebug() << "ПЕРЕМОГА (зареган)";
}

void Server::LogInUser(QString log_pass)
{
    //тут такая же ситуация
    /*
    QString login = ui->loginInput->text();
    QString password = ui->passwordInput->text();
    if (database.userExist(login, password)){
        emit userLoggedIn();
        this->close();
    }
*/
    qDebug() << "ПЕРЕМОГА (залогинен)";
}

