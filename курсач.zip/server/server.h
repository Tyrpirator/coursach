#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QVector>
#include <QJsonDocument>
#include <QJsonObject>

#include "databasemanager.h"

class Server : public QTcpServer
{
    Q_OBJECT
public:
    Server();
    void startServer();

private:
    QTcpSocket *socket;

    QVector <QTcpSocket*> Sockets;
    QByteArray Data;
    QByteArray Metadata;
    DatabaseManager databaseManager;
    QJsonObject metadata;
    qint16 BlockSize = 0;

    void sendToClient(QString);

    void registerUser(QString);
    void LogInUser(QString);

public slots:
    void incomingConnection(qintptr socketDescriptor) override;
    void slotReadyRead();
    void userDisconnected();
};

#endif // SERVER_H
