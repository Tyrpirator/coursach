#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSql>

class DatabaseManager
{
public:
    DatabaseManager();

    bool registerUser(QString, QString);
    bool userExist(QString, QString);
    void createPrivateChat(QString, QString);

private:
    QSqlDatabase database_users;
    QSqlDatabase database_chats;
    QSqlQuery* query;
};

#endif // DATABASEMANAGER_H
