#include "databasemanager.h"

DatabaseManager::DatabaseManager()
    : database_users(QSqlDatabase::addDatabase("QSQLITE", "connection1"))
    , database_chats(QSqlDatabase::addDatabase("QSQLITE", "connection2"))
    , query(new QSqlQuery(database_users))
{
    database_users.setDatabaseName("users.db");
    database_chats.setDatabaseName("chats.db");

    if (database_users.open())
    {
        query->exec("CREATE TABLE IF NOT EXISTS usersList (id INT AUTO_INCREMENT PRIMARY KEY, login VARCHAR(15) NOT NULL, password VARCHAR(30) NOT NULL);");
        qDebug() << database_users.tables().size();
    }
    else
    {
        qDebug() << "ERROR: Database didnt open";
    }
    database_users.close();
}

bool DatabaseManager::registerUser(QString login, QString password)
{
    if (database_users.open())
    {
        query->exec("USING usersList;");
        //QSqlDatabase::database().transaction();
        query->exec("SELECT * FROM usersList WHERE login = '" + login + "';");
        qDebug() << query->value(0).toString() << database_users.tables().size();

        if (query->next())
        {
            qDebug() << "NOT REGISTERED";
            return false;
        }
        else
        {
            qDebug() << "REGISTERED";
            query->prepare("INSERT INTO usersList (login,password) VALUES (:log,:pass);");
            query->bindValue(":log", login);
            query->bindValue(":pass", password);
            query->exec();
            return true;
        }
    }
    //QSqlDatabase::database().commit();
    database_users.close();
}

bool DatabaseManager::userExist(QString login, QString password)
{
    if (database_users.open())
    {
        query->exec("USING usersList;");
        query->exec("SELECT * FROM usersList WHERE login = '" + login + "' AND password = '" + password + "';");
        qDebug() << query->value(0).toString() << database_users.tables().size();

        return query->next();
    }
    database_users.close();
}

void DatabaseManager::createPrivateChat(QString userID_1, QString userID_2)
{

}
