#include "messengerwindow.h"
#include "ui_messengerwindow.h"

MessengerWindow::MessengerWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MessengerWindow)
{
    ui->setupUi(this);
}
