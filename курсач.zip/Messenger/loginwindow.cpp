#include "loginwindow.h"
#include "ui_loginwindow.h"

LoginWindow::LoginWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LoginWindow)
{
    ui->setupUi(this);
    socket = new QTcpSocket(this);
    connect(socket, &QTcpSocket::readyRead, this, &LoginWindow::readyReadSlot);
    connect(socket, &QTcpSocket::disconnected, this, &LoginWindow::deleteLater);
    socket->connectToHost("127.0.0.1", 5555);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}

void LoginWindow::sendToServer(QString data, QString metadata)
{
    Data.clear();
    QDataStream out(&Data, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_2);
    out << qint16(0) << data;
    out.device()->seek(0);
    out << qint16(Data.size() - sizeof(qint16));

    this->metadata["type"] = metadata;
    QJsonObject package;
    package["metadata"] = this->metadata;
    package["data"] = QString(Data.toBase64());
    QJsonDocument jsonDoc(package);
    QByteArray JData = jsonDoc.toJson();

    socket->write(JData);
    socket->waitForBytesWritten();
}

void LoginWindow::on_registerButton_clicked()
{
    QString login = ui->loginInput->text();
    QString password = ui->passwordInput->text();
    sendToServer(login + "!" + password, "register");
}


void LoginWindow::on_loginButton_clicked()
{
    QString login = ui->loginInput->text();
    QString password = ui->passwordInput->text();
    sendToServer(login + "!" + password, "login");
    /*
    QString login = ui->loginInput->text();
    QString password = ui->passwordInput->text();
    if (database.userExist(login, password)){
        emit userLoggedIn();
        this->close();
    }
*/
}

void LoginWindow::readyReadSlot()
{
    QDataStream in(socket);
    in.setVersion(QDataStream::Qt_6_2);
    if (in.status() == QDataStream::Ok) {
        while(true)
        {
            if (BlockSize == 0){
                if (socket->bytesAvailable() < 2){
                    break;
                }
                in >> BlockSize;
            }
            if (socket->bytesAvailable() < BlockSize){
                break;
            }

            QString data;    ////какие то данные от сервера
            in >> data;
        }
    } else {
        qDebug() << "ERROR Data lose";
    }
}

