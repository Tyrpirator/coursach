#ifndef MESSENGERWINDOW_H
#define MESSENGERWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MessengerWindow;
}
QT_END_NAMESPACE

class MessengerWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MessengerWindow(QWidget *parent = nullptr);
    ~MessengerWindow() override = default;

private:
    Ui::MessengerWindow *ui;
};
#endif // MESSENGERWINDOW_H
