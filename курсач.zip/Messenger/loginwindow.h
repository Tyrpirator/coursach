#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QWidget>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonDocument>

namespace Ui {
class LoginWindow;
}

class LoginWindow : public QWidget
{
    Q_OBJECT

public:
    explicit LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow() override;

    void sendToServer(QString, QString);

private:
    Ui::LoginWindow *ui;

    QTcpSocket *socket;

    QByteArray Data;
    QByteArray Metadata;
    QJsonObject metadata;
    qint16 BlockSize = 0;

signals:
    void userLoggedIn();

private slots:
    void on_registerButton_clicked();
    void on_loginButton_clicked();

public slots:
    void readyReadSlot();
};

#endif // LOGINWINDOW_H
